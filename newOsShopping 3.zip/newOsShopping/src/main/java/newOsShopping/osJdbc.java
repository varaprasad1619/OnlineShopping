package newOsShopping;

public class osJdbc 
{
	public static String url="jdbc:mysql://10.5.0.24:3307/prasad";
	public static String user="root";
	public static String password="finsol";
	public static String Driver="com.mysql.jdbc.Driver";
}
